# Keep-Inventory-Orbs
A fully server-side approach to the gravestone concept introducing 'orbs' to store your inventory upon death.<br>
For more information visit the [modrinth](https://modrinth.com/datapack/keep-inventory-orbs) side<br>
Bug reports [here](https://github.com/CreepermeYT/Keep-Inventory-Orbs/issues)
